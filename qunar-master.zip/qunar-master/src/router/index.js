/* eslint-disable */
import Vue from 'vue'
/* eslint-disable */
import Router from 'vue-router'
/* eslint-disable */
import Index from 'pages/home/index'
/* eslint-disable */
import City from 'pages/city/index'
/* eslint-disable */
import Detail from 'pages/detail/index'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    name: 'index',
    component: Index
  }, {
    path: '/city',
    name: 'city',
    component: City
  }, {
    path: '/detail/:sightId',
    name: 'detail',
    component: Detail,
    props: true
  }]
})
