export default {
  city: '北京'
}
