export default {
  changeCity (state, city) {
    state.city = city
  }
}
