/* eslint-disable */
import Vue from 'vue'
/* eslint-disable */
import Vuex from 'Vuex'
/* eslint-disable */
import state from './state'
/* eslint-disable */
import mutations from './mutations'

Vue.use(Vuex)

export default new Vuex.Store({
  state,
  mutations
})
