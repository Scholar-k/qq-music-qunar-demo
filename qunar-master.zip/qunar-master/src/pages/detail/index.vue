<template>
  <div>
    <banner :bannerImg="bannerImg" :imgList="imgList"></banner>
    <detail-header></detail-header>
    <list :list="ticketList"></list>
    <download v-show="download" @close="handleClose">download...</download>
  </div>
</template>

<script>
  /* eslint-disable */
  import Banner from './banner'
  /* eslint-disable */
  import Download from 'components/common/download/index'
  /* eslint-disable */
  import List from './list'
  /* eslint-disable */
  import DetailHeader from './header'
  /* eslint-disable */
  import axios from 'axios'
  /* eslint-disable */
  import download from 'mixins/download'
  export default {
    name: 'detail',
    mixins: [download],
    props: {
      sightId: [Number, String]
    },
    data () {
      return {
        bannerImg: '',
        imgList: [],
        ticketList: [],
        download: false
      }
    },
    components: {
      Banner,
      Download,
      List,
      DetailHeader
    },
    created () {
      this.getDetailInfo()
    },
    watch: {
      sightId () {
        if (this.sightId) {
          this.getDetailInfo()
        }
      }
    },
    methods: {
      getDetailInfo () {
        axios.get('/api/detail.json', {
          patams: {
            id: this.sightId
          }
        }).then(this.handleGetDetailSucc.bind(this)).catch(this.handleGetDetailErr.bind(this))
      },
      handleGetDetailSucc (res) {
        res && (res = res.data)
        if (res && res.ret && res.data) {
          this.bannerImg = res.data.bannerImg
          this.imgList = res.data.imgList
          this.ticketList = res.data.ticketList
        } else {
          this.handleGetDetailErr()
        }
      },
      handleGetDetailErr () {
        console.log('error')
      },
      showDownload () {
        this.download = true
      },
      handleClose () {
        this.download = false
      }
    }
  }
</script>

<style scoped lang="stylus">
</style>
