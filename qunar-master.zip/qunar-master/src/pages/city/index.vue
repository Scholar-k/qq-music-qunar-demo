<template>
  <div class="main">
    <city-header></city-header>
    <search :list="list"></search>
    <list class="list" :list="list" :hotcity="hotcity" ref="list" @scroll="handleListScroll" @fixchange="handleFixChange"></list>
    <sidebar :list="list" @changeLetter="handleLetterChange"></sidebar>
  </div>
</template>

<script>
  /* eslint-disable */
  import CityHeader from './header'
  /* eslint-disable */
  import Search from './search'
  /* eslint-disable */
  import List from './list'
  /* eslint-disable */
  import Sidebar from './sidebar'
  /* eslint-disable */
  import axios from 'axios'
  export default {
    name: 'city',
    data () {
      return {
        list: {},
        hotcity: []
      }
    },
    components: {
      CityHeader,
      Search,
      List,
      Sidebar
    },
    methods: {
      getListInfo () {
        axios.get('/api/city.json').then(this.handleGetListSucc.bind(this)).catch(this.handleGetListErr.bind(this))
      },
      handleGetListSucc (res) {
        res && (res = res.data)
        if (res && res.data) {
          res.data.list && (this.list = res.data.list)
          res.data.hotcity && (this.hotcity = res.data.hotcity)
        } else {
          this.handleGetListErr()
        }
      },
      handleGetListErr () {
        console.log('请求返回失败')
      },
      handleLetterChange (item) {
        this.$refs.list.scrollToIndex(item)
      },
      handleListScroll (e) {
        this.$refs.fixedTitle.setShow(!(e.y > 0))
      },
      handleFixChange (num) {
        this.$refs.fixedTitle.setMove(num || 0)
      }
    },
    created () {
      this.getListInfo()
    }
  }
</script>

<style scoped lang="stylus">
  @import '../../assets/styles/common/varibles.styl'
  .main
    display: flex
    flex-direction: column
    position: absolute
    left: 0
    right: 0
    top: 0
    bottom: 0
    .list
      overflow: hidden
      flex: 1
</style>
