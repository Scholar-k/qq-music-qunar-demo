// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
/* eslint-disable */
import Vue from 'vue'
/* eslint-disable */
import App from './App'
/* eslint-disable */
import router from './router'
/* eslint-disable */
import Fastclick from 'fastclick'
/* eslint-disable */
import VueAwesomeSwiper from 'vue-awesome-swiper'
/* eslint-disable */
import VueLazyload from 'vue-lazyload'
/* eslint-disable */
import store from 'store/'
/* eslint-disable */
import 'styles/base/reset.css'
/* eslint-disable */
import 'styles/base/border.css'
/* eslint-disable */
import 'styles/base/iconfont/iconfont.css'
/* eslint-disable */
import 'swiper/dist/css/swiper.css'

Vue.config.productionTip = false
Fastclick.attach(document.body)
Vue.use(VueAwesomeSwiper)
Vue.use(VueLazyload, {
  preLoad: 1.3,
  error: 'http://img1.qunarzz.com/sight/p0/201306/13/bdf22f69fab0ee4ec8d65eac.jpg_140x140_355f4fb6.jpg',
  loading: 'http://img1.qunarzz.com/sight/p0/201306/13/bdf22f69fab0ee4ec8d65eac.jpg_140x140_355f4fb6.jpg',
  attempt: 1
})

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
