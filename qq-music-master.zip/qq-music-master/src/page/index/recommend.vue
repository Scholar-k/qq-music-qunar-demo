<template>
  <div>
    <header class="header">
      <div class="user-name">Dell's Music</div>
    </header>
  </div>
</template>

<script>
export default {
  name: 'Recommend'
}
</script>

<style scoped>

</style>
