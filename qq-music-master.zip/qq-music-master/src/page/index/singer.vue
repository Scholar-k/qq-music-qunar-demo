<template>
  <div>
    <header class="header">
      <div class="user-name">Dell's Music</div>
    </header>

    <div class="nav-list">
      <nav>
        <li><router-link to="./recommend"><span class="active">推荐</span></router-link></li>
        <li><router-link to="./singer"><span>歌手</span></router-link></li>
        <li><router-link to="./ranking"><span>排行</span></router-link></li>
        <li><router-link to="./search"><span>搜索</span></router-link></li>
      </nav>
    </div>
</template>

<script>

</style>
