<template>
  <div>
  	<header class="header">
  	  <div class="user-name">Dell's Music</div>
  	</header>

  	<div class="nav-list">
  	  <nav>
  	  	<li><router-link to="./recommend"><span class="active">推荐</span></router-link></li>
  	  	<li><router-link to="./singer"><span>歌手</span></router-link></li>
  	  	<li><router-link to="./ranking"><span>排行</span></router-link></li>
  	  	<li><router-link to="./search"><span>搜索</span></router-link></li>
  	  </nav>
  	</div>
  	
    <swiper :options="sliderOption">
      <swiper-slide v-for='(item, index) in sliderInfo' :key='item.id'>
        <div class="swiper-img-con">
          <img  class="swiper-img" :src="item.picUrl"/>
        </div>
      </swiper-slide>
      <div class="swiper-pagination"  slot="pagination"></div>
    </swiper>

		<h2 class="hotSal">热门歌单推荐</h2>

    <div class="lazy-load" ref="hotContain">
    	<ul class="hotSal_list">
    		<li class="mp-hot-li" v-for="(item, index) in listInfo" :key="index">
    			<a href="javascript:;">
    				<div class="hot-li-img"><img :src="item.picUrl" /></div>
    				<div class="mp-hotlist-infos">
    					<div class="mp-hotlist-title">{{item.title}}</div>
    					<div class="mp-hotlist-desc overflowOmit">{{item.desc}}</div>
    				</div>
    			</a>
    		</li>
    	</ul>  
    </div>
  </div>
</template>

<script>
import BScroll from 'better-scroll'
export default {
  name: 'Index',
  data () {
    return {
      sliderInfo: [],
      listInfo: [],
      sliderOption: {
        autoplay: 2000,
        loop: true,
        pagination: '.swiper-pagination'
      }
    }
  },
  methods: {
    getDataIndex () {
      this.$http.get('./static/index.json')
      .then(this.handleDataSucc.bind(this))
    },
    handleDataSucc (res) {
      const body = res.body
      if (body && body.data && body.data.slider) {
        this.sliderInfo = body.data.slider
        this.listInfo = body.data.list
      }
    }
  },
  created () {
    this.getDataIndex()
  },
  mounted () {
    this.scroll = new BScroll(this.$refs.hotContain)
  }
}
</script>

<style scoped>
  .header,.nav-list {
    display: flex;
    background: #000;
    min-height: .8rem;
  }
  .user-name {
    width: 100%;
    line-height: .8rem;
    text-align: center;
    font-size: .42rem;
    color: yellow;
  }
  .nav-list nav {
  	width: 100%;
  	color: #fff;
  	list-style: none;
  }
  .nav-list nav li {
  	width: 25%;
  	height: .8rem;
  	line-height: .8rem;
  	text-align: center;
  	float: left;
  	font-size:.32rem;
  }
  .nav-list nav li span{
  	color: #fff;
  }
  .nav-list .active {
  	color: yellow;
  }
  .swiper-img-con {
    overflow: hidden;
    width: 100%;
    height: 0;
    padding-bottom: 40%;
  }
  .swiper-img {
    width: 100%;
  }
	.lazy-load{
		overflow: hidden;
		height: 8rem;
		background: #000;
		width: 100%;
	}
	.hotSal{
		height: .8rem;
		background: #000;
		color: #fff;
		line-height: .8rem;
		font-size: .30rem;
		text-align: center;
	}
	.hotSal_list{
		width: 100%;
	}
	.mp-hot-li{
		height: 1.4rem;
		width: 100%;
		position: relative;
		padding: .24rem;
	}
	.hot-li-img{
		position: absolute;
		top: .24rem;
		left: .24rem;
		width: 1.4rem;
		height: 1.4rem;
	}
	.hot-li-img img{
		width: 1.4rem;
		height: 1.4rem;
	}
	.mp-hotlist-infos{
		margin-left: 1.6rem;
	}
	.mp-hotlist-title{
		margin-top: 0.2rem;
		font-size: .3rem;
		color: #fff;
	}
	.mp-hotlist-desc{
		margin-top: 0.15rem;
		color: #9e9e9e;
	}
</style>
