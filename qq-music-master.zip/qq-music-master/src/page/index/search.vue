<template>
  <div>
  	<header class="header">
  	  <div class="user-name">Dell's Music</div>
  	</header>

  	<div class="nav-list">
  	  <nav>
  	  	<li><router-link to="./recommend"><span class="active">推荐</span></router-link></li>
  	  	<li><router-link to="./singer"><span>歌手</span></router-link></li>
  	  	<li><router-link to="./ranking"><span>排行</span></router-link></li>
  	  	<li><router-link to="./search"><span>搜索</span></router-link></li>
  	  </nav>
  	</div>
</template>

<script>
export default {
  name: 'Search'
}
</script>

<style scoped>
  .header,.nav-list {
    display: flex;
    background: #000;
    min-height: .8rem;
  }
  .user-name {
    width: 100%;
    line-height: .8rem;
    text-align: center;
    font-size: .42rem;
    color: yellow;
  }
  .nav-list nav {
  	width: 100%;
  	color: #fff;
  	list-style: none;
  }
  .nav-list nav li {
  	width: 25%;
  	height: .8rem;
  	line-height: .8rem;
  	text-align: center;
  	float: left;
  	font-size:.32rem;
  }
  .nav-list nav li span{
  	color: #fff;
  }
  .nav-list .active {
  	color: yellow;
  }
  .swiper-img-con {
    overflow: hidden;
    width: 100%;
    height: 0;
    padding-bottom: 40%;
  }
  .swiper-img {
    width: 100%;
  }
</style>
